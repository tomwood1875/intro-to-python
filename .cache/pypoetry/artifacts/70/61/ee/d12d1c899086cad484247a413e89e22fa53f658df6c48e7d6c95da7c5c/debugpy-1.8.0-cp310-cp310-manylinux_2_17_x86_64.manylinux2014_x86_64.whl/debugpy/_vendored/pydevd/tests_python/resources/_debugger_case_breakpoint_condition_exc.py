def Call():
    for i in range(10):  # break here
        last_i = i


if __name__ == '__main__':
    Call()
    print('TEST SUCEEDED!')
