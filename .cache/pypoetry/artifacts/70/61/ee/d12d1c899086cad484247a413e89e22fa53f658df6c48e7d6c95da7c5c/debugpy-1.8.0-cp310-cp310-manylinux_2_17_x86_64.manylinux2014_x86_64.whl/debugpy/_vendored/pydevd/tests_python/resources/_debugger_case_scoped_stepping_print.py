a = 1
b = 2
from email.utils import unquote  # break here
print(unquote('something " to unquote'))  # pause 1
d = 4  # pause 2

print('end')  # pause 3
