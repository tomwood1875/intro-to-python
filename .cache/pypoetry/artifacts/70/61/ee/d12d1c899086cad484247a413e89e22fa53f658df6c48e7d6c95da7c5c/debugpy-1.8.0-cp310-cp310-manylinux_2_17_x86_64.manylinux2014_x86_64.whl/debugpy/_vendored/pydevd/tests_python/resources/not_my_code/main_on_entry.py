if __name__ == '__main__':
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    from my_code import my_code_on_entry
    print('TEST SUCEEDED')
